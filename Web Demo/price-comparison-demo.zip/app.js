// Global Price Comparison Tool JavaScript

// Sample data for demonstration
const sampleData = {
  "US_iPhone": [
    {
      "link": "https://www.apple.com/iphone-16-pro/",
      "price": "999.00",
      "currency": "USD",
      "productName": "Apple iPhone 16 Pro 128GB",
      "vendor": "Apple Store",
      "availability": "in_stock"
    },
    {
      "link": "https://www.amazon.com/dp/iPhone16Pro",
      "price": "1049.99", 
      "currency": "USD",
      "productName": "iPhone 16 Pro (128GB) - Natural Titanium",
      "vendor": "Amazon",
      "availability": "in_stock"
    },
    {
      "link": "https://www.bestbuy.com/site/iphone-16-pro",
      "price": "1099.99",
      "currency": "USD", 
      "productName": "Apple iPhone 16 Pro 128GB Unlocked",
      "vendor": "Best Buy",
      "availability": "in_stock"
    }
  ],
  "IN_boAt": [
    {
      "link": "https://www.boat-lifestyle.com/products/airdopes-311-pro",
      "price": "2999.00",
      "currency": "INR",
      "productName": "boAt Airdopes 311 Pro TWS Earbuds",
      "vendor": "boAt Official",
      "availability": "in_stock"
    },
    {
      "link": "https://www.amazon.in/dp/B08XXXX",
      "price": "3499.00",
      "currency": "INR",
      "productName": "boAt Airdopes 311 Pro Wireless Earbuds",
      "vendor": "Amazon India",
      "availability": "in_stock"
    },
    {
      "link": "https://www.flipkart.com/boat-airdopes-311-pro",
      "price": "3299.00",
      "currency": "INR",
      "productName": "boAt Airdopes 311 Pro True Wireless Earbuds",
      "vendor": "Flipkart",
      "availability": "in_stock"
    }
  ]
};

// Countries data
const countries = [
  {"code": "US", "name": "United States", "currency": "USD", "flag": "🇺🇸"},
  {"code": "IN", "name": "India", "currency": "INR", "flag": "🇮🇳"},
  {"code": "UK", "name": "United Kingdom", "currency": "GBP", "flag": "🇬🇧"},
  {"code": "JP", "name": "Japan", "currency": "JPY", "flag": "🇯🇵"}
];

// DOM Elements
const searchForm = document.getElementById('searchForm');
const countrySelect = document.getElementById('country');
const queryInput = document.getElementById('query');
const searchBtn = document.getElementById('searchBtn');
const btnText = searchBtn.querySelector('.btn-text');
const btnSpinner = searchBtn.querySelector('.btn-spinner');

const loadingSection = document.getElementById('loadingSection');
const resultsSection = document.getElementById('resultsSection');
const resultsTitle = document.getElementById('resultsTitle');
const resultsCount = document.getElementById('resultsCount');
const resultsGrid = document.getElementById('resultsGrid');

// Example buttons
const exampleButtons = document.querySelectorAll('.example-btn');

// Current search state
let isSearching = false;

// Initialize the application
function init() {
  setupEventListeners();
  setupExampleButtons();
}

// Set up event listeners
function setupEventListeners() {
  searchForm.addEventListener('submit', handleSearch);
}

// Set up example buttons
function setupExampleButtons() {
  exampleButtons.forEach(button => {
    button.addEventListener('click', () => {
      const country = button.getAttribute('data-country');
      const query = button.getAttribute('data-query');
      
      // Set form values
      countrySelect.value = country;
      queryInput.value = query;
      
      // Trigger search
      handleSearch(new Event('submit'));
    });
  });
}

// Handle search form submission
async function handleSearch(event) {
  event.preventDefault();
  
  if (isSearching) return;
  
  const country = countrySelect.value;
  const query = queryInput.value.trim();
  
  if (!country || !query) {
    showError('Please select a country and enter a product query.');
    return;
  }
  
  await performSearch(country, query);
}

// Perform the search operation
async function performSearch(country, query) {
  try {
    isSearching = true;
    showLoadingState();
    hideResults();
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Get sample results based on query
    const results = getSampleResults(country, query);
    
    hideLoadingState();
    displayResults(results, country, query);
    
  } catch (error) {
    console.error('Search error:', error);
    hideLoadingState();
    showError('An error occurred while searching. Please try again.');
  } finally {
    isSearching = false;
  }
}

// Get sample results based on country and query
function getSampleResults(country, query) {
  // Simple keyword matching for demo purposes
  const queryLower = query.toLowerCase();
  
  if (country === 'US' && (queryLower.includes('iphone') || queryLower.includes('16 pro'))) {
    return sampleData.US_iPhone;
  } else if (country === 'IN' && (queryLower.includes('boat') || queryLower.includes('airdopes'))) {
    return sampleData.IN_boAt;
  } else {
    // Generate mock results for other queries
    return generateMockResults(country, query);
  }
}

// Generate mock results for queries not in sample data
function generateMockResults(country, query) {
  const countryInfo = countries.find(c => c.code === country);
  const currency = countryInfo ? countryInfo.currency : 'USD';
  
  const vendors = {
    'US': ['Amazon', 'Best Buy', 'Walmart', 'Target'],
    'IN': ['Amazon India', 'Flipkart', 'Snapdeal', 'Myntra'],
    'UK': ['Amazon UK', 'Currys', 'Argos', 'John Lewis'],
    'JP': ['Amazon Japan', 'Rakuten', 'Yodobashi', 'Bic Camera']
  };
  
  const basePrice = Math.floor(Math.random() * 1000) + 100;
  const results = [];
  
  for (let i = 0; i < 3; i++) {
    const priceVariation = Math.floor(Math.random() * 200) - 100;
    const finalPrice = basePrice + priceVariation + (i * 50);
    
    results.push({
      productName: `${query} - ${vendors[country][i] || 'Local Store'}`,
      price: finalPrice.toFixed(2),
      currency: currency,
      vendor: vendors[country][i] || 'Local Store',
      link: '#',
      availability: 'in_stock'
    });
  }
  
  // Sort by price
  return results.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
}

// Show loading state
function showLoadingState() {
  btnText.classList.add('hidden');
  btnSpinner.classList.remove('hidden');
  searchBtn.disabled = true;
  
  loadingSection.classList.remove('hidden');
  loadingSection.classList.add('fade-in');
}

// Hide loading state
function hideLoadingState() {
  btnText.classList.remove('hidden');
  btnSpinner.classList.add('hidden');
  searchBtn.disabled = false;
  
  loadingSection.classList.add('hidden');
}

// Display search results
function displayResults(results, country, query) {
  if (!results || results.length === 0) {
    showNoResults(query);
    return;
  }
  
  // Sort results by price (ascending)
  const sortedResults = [...results].sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
  
  // Update results header
  const countryInfo = countries.find(c => c.code === country);
  const countryName = countryInfo ? countryInfo.name : country;
  
  resultsTitle.textContent = `Results for "${query}" in ${countryName}`;
  resultsCount.textContent = `Found ${sortedResults.length} product${sortedResults.length !== 1 ? 's' : ''}`;
  
  // Clear previous results
  resultsGrid.innerHTML = '';
  
  // Create result cards
  sortedResults.forEach((result, index) => {
    const resultCard = createResultCard(result, index);
    resultsGrid.appendChild(resultCard);
  });
  
  // Show results section
  resultsSection.classList.remove('hidden');
  resultsSection.classList.add('fade-in');
  
  // Scroll to results
  resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Create a result card element
function createResultCard(result, index) {
  const card = document.createElement('div');
  card.className = 'result-card slide-in';
  card.style.animationDelay = `${index * 0.1}s`;
  
  const availabilityClass = result.availability === 'in_stock' ? 'result-availability--in-stock' : 'result-availability--out-of-stock';
  const availabilityText = result.availability === 'in_stock' ? 'In Stock' : 'Out of Stock';
  
  card.innerHTML = `
    <div class="result-header">
      <div class="result-price">
        ${formatPrice(result.price, result.currency)}
        <span class="result-currency">${result.currency}</span>
      </div>
    </div>
    <h3 class="result-title">${escapeHtml(result.productName)}</h3>
    <div class="result-meta">
      <span class="result-vendor">${escapeHtml(result.vendor)}</span>
      <span class="result-availability ${availabilityClass}">
        ${availabilityText}
      </span>
    </div>
    <a href="${result.link}" target="_blank" class="result-link">
      View Product
    </a>
  `;
  
  return card;
}

// Format price with proper currency symbols
function formatPrice(price, currency) {
  const numPrice = parseFloat(price);
  
  const currencySymbols = {
    'USD': '$',
    'INR': '₹',
    'GBP': '£',
    'JPY': '¥'
  };
  
  const symbol = currencySymbols[currency] || currency;
  
  if (currency === 'JPY') {
    // Japanese Yen doesn't use decimal places
    return `${symbol}${Math.round(numPrice).toLocaleString()}`;
  }
  
  return `${symbol}${numPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// Show no results message
function showNoResults(query) {
  resultsTitle.textContent = `No results found for "${query}"`;
  resultsCount.textContent = 'Try a different search term or country';
  
  resultsGrid.innerHTML = `
    <div class="no-results card">
      <div class="card__body text-center">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
        <h3>No products found</h3>
        <p>We couldn't find any products matching your search. Try different keywords or select another country.</p>
      </div>
    </div>
  `;
  
  resultsSection.classList.remove('hidden');
  resultsSection.classList.add('fade-in');
}

// Hide results section
function hideResults() {
  resultsSection.classList.add('hidden');
}

// Show error message
function showError(message) {
  // Create error notification
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-notification';
  errorDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: var(--color-error);
    color: white;
    padding: 16px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 1000;
    max-width: 400px;
    animation: slideIn 0.3s ease-out;
  `;
  errorDiv.textContent = message;
  
  document.body.appendChild(errorDiv);
  
  // Remove after 5 seconds
  setTimeout(() => {
    if (errorDiv.parentNode) {
      errorDiv.style.animation = 'fadeOut 0.3s ease-out';
      setTimeout(() => {
        document.body.removeChild(errorDiv);
      }, 300);
    }
  }, 5000);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Add CSS for error notification animation
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeOut {
    from { opacity: 1; transform: translateX(0); }
    to { opacity: 0; transform: translateX(100%); }
  }
  
  .no-results {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem 2rem;
  }
  
  .no-results h3 {
    color: var(--color-text);
    margin-bottom: 1rem;
  }
  
  .no-results p {
    color: var(--color-text-secondary);
    margin: 0;
    max-width: 400px;
    margin: 0 auto;
  }
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Add smooth scrolling for better UX
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Add keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // Ctrl/Cmd + K to focus search
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    queryInput.focus();
  }
  
  // Escape to clear results
  if (e.key === 'Escape' && !isSearching) {
    hideResults();
    queryInput.focus();
  }
});

// Add search input enhancements
queryInput.addEventListener('input', (e) => {
  // Simple validation feedback
  const value = e.target.value.trim();
  if (value.length > 0 && value.length < 3) {
    queryInput.style.borderColor = 'var(--color-warning)';
  } else {
    queryInput.style.borderColor = 'var(--color-border)';
  }
});

// Add enter key support for example buttons
exampleButtons.forEach(button => {
  button.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      button.click();
    }
  });
  
  // Make buttons focusable
  button.setAttribute('tabindex', '0');
});